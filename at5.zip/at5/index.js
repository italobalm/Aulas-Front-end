//Questão 1
//O comando "for" é utilizado como loop para repetir algo enquanto uma condição 
//for verdadeira e sabe-se com antecedência quantas vezes deseja repetir uma ação.
//Questão 2
//O incio é definido através da declaração de uma variável que será controlada 
//ao longo do código. Ex: for (let i = 0;). A repetição inicia no 0.
//Questão 3
//O fim da execução é definido logo após a declaração do ponto de partida,
//onde se diz até que momento aquela repetição acontecerá.
//Ex: for (let i = 0; i < 10). A repetição inicia em 0 e continua enquanto i for menor que 10.
//Questão 4
//A alteração do valor ocorre através do incremento "++".
//Ex: for (let i = 0; i < 10; i++){}.
//Questão 5
for (var i = 0; i < 10; i++) {
    console.log("Testando uma frase!");
}
;
//Questão 6
for (var y = 0; y < 10; y++) {
    console.log(y);
}
;
//Questão 7
for (var z = 0; z < 10; z++) {
    if (z == 5) {
        break;
    }
    ;
    console.log(z);
}
;
//Questão 8
for (var x = 0; x < 10; x++) {
    if (x == 5) {
        continue;
    }
    ;
    console.log(x);
}
;
//Questão 9
var nomes = ['João', 'Paulo', 'Pedro', 'Gustavo', 'Maria'];
for (var _i = 0, nomes_1 = nomes; _i < nomes_1.length; _i++) {
    var n = nomes_1[_i];
    console.log(n);
}
;
//Questão 10
for (var h = 1; h < 11; h++) {
    console.log(h);
}
;
//Questão 11
for (var g = 10; g > 0; g--) {
    console.log(g);
}
;
//Questão 12
var soma = 0;
for (var num = 0; num < 101; num++) {
    soma = soma + num;
}
;
console.log(soma);
//Questão 13
for (var p = 1; p < 51; p++) {
    if (p % 2 == 0) {
        console.log(p);
    }
    ;
}
;
//Questão 14
var produto = 1;
for (var u = 1; u < 6; u++) {
    produto = produto * u;
}
;
console.log(produto);
//Questão 15
for (var b = 1; b < 11; b++) {
    console.log("7x".concat(b, " = ").concat(7 * b));
}
;
//Questão 16
//let somar = 0;
//for (let w = 0; w < 5; w++){
//    let notas = (Number(prompt(`Digite a ${w}º nota:`)));
//   somar = somar + notas;
//};
//console.log(`A média das notas é igual a ${somar/5}`);
//Questão 17
for (var d = 1; d < 51; d++) {
    if (d % 3 == 0) {
        console.log(d);
    }
    ;
}
;
//Questão 18
var maiorNumero = 0;
var menorNumero = 554874873487548;
for (var t = 1; t < 11; t++) {
    var numero = (Number(prompt("Digite o ".concat(t, "\u00BA n\u00FAmero:"))));
    if (numero > maiorNumero) {
        maiorNumero = numero;
    }
    ;
    if (numero < menorNumero) {
        menorNumero = numero;
    }
    ;
}
;
console.log("Maior n\u00FAmero: ".concat(maiorNumero, " Menor n\u00FAmero: ").concat(menorNumero));
//Questão 19
for (var q = 1; q < 101; q++) {
    if (q % 2 != 0) {
        console.log(q);
    }
    ;
}
;
//Questão 20
var aprovados = 0;
for (var f = 1; f < 6; f++) {
    var nota = (Number(prompt("Digite a nota do ".concat(f, "\u00BA aluno:"))));
    if (nota >= 7) {
        aprovados += 1;
    }
}
;
console.log("".concat(aprovados, " alunos foram aprovados!"));
//Questão 21
var numInteiro = (String(prompt("Digite um número inteiro:")));
var adicao = 0;
for (var s = 0; s < numInteiro.length; s++) {
    adicao += parseInt(numInteiro[s]);
}
;
//Questão 22
for (var k = 1; k < 101; k++) {
    var inteiro = (Number(prompt("Digite um número inteiro:")));
    if (inteiro % k == 0) {
        console.log(k);
    }
    ;
}
;
//Questão 23
var somarAlturas = 0;
for (var a = 1; a < 6; a++) {
    var altura = (Number(prompt("Digite a ".concat(a, "\u00BA altura:"))));
    somarAlturas += altura;
}
;
console.log("A m\u00E9dia de alturas \u00E9 ".concat(somarAlturas / 5));
//Questão 24
for (var c = 1; c < 101; c++) {
    if (c % 3 == 0 && c % 5 != 0) {
        console.log("Fizz");
    }
    else if (c % 5 == 0 && c % 3 != 0) {
        console.log("Buzz");
    }
    else if (c % 3 == 0 && c % 5 == 0) {
        console.log("FizzBuzz");
    }
    else {
        console.log(c);
    }
    ;
}
;
//Questão 25
var somaPares = 0;
var numeral = (String(prompt("Digite um número inteiro:")));
//Questão 26
var valorInvertido = '';
var digito = (String(prompt("Digite um número inteiro:")));
for (var u = digito.length - 1; u >= 0; u--) {
    valorInvertido += digito[u];
}
;
console.log(valorInvertido);
